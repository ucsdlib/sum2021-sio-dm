

# create the folders - use quotes because there are spaces:  
# mkdir "Folder with Spaces"
# mkdir "Folder with Spaces/Subfolder with Spaces"
# note you have to create the parent folder before you create the child folder. 


#copy files into the folders


#finally zip up Processing and Analysis using tar
#leave the below alone, this will be used in grading
tar -zcvf process-data.tar.gz "Processing and Analysis/"

